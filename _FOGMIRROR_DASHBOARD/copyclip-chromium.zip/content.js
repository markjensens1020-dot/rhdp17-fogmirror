// CopyClip – Auto-capture, auto-copy, read-aloud & selection toolbar
(function () {
  let lastSaved = "";
  let lastSpoken = "";
  let debounceTimer = null;
  let toolbarEl = null;
  let hideTimer = null;
  let settings = {
    autoCopy: true,
    readAloud: false,
    deduplication: true,
    showToolbar: true,
    voiceURI: "",
    speechRate: 1,
  };

  // Load settings + keep them in sync
  try {
    chrome.storage.local.get(["settings"], (r) => {
      if (r && r.settings) Object.assign(settings, r.settings);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.settings && changes.settings.newValue) {
        Object.assign(settings, changes.settings.newValue);
        if (!settings.readAloud) stopSpeaking();
        if (!settings.showToolbar) hideToolbar();
      }
    });
  } catch (e) {}

  document.addEventListener("mouseup", handleSelection);
  document.addEventListener("keyup", handleSelection);
  document.addEventListener("scroll", hideToolbar, true);
  document.addEventListener("mousedown", (e) => {
    if (toolbarEl && !toolbarEl.contains(e.target)) hideToolbar();
  });

  function handleSelection(e) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const sel = window.getSelection();
      const text = sel ? sel.toString().trim() : "";
      if (!text || text.length < 2) {
        hideToolbar();
        return;
      }

      // 1) Auto-copy
      if (settings.autoCopy !== false && text !== lastSaved) {
        copyToClipboard(text);
      }

      // 2) Read aloud
      if (settings.readAloud && text !== lastSpoken) {
        lastSpoken = text;
        speak(text);
      }

      // 3) Save to history
      if (text !== lastSaved) {
        lastSaved = text;
        try {
          chrome.runtime.sendMessage(
            { type: "SAVE_CLIP", content: text, source: location.href },
            () => {
              if (chrome.runtime.lastError) {}
            }
          );
        } catch (e) {}
      }

      // 4) Selection toolbar
      if (settings.showToolbar !== false) showToolbar(sel, text);
    }, 250);
  }

  function copyToClipboard(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
      } else {
        fallbackCopy(text);
      }
    } catch (e) {
      fallbackCopy(text);
    }
  }

  function fallbackCopy(text) {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    } catch (e) {}
  }

  function getVoice() {
    try {
      if (!("speechSynthesis" in window)) return null;
      const voices = window.speechSynthesis.getVoices();
      if (!voices || !voices.length) return null;
      if (settings.voiceURI) {
        const v = voices.find((x) => x.voiceURI === settings.voiceURI);
        if (v) return v;
      }
      return voices.find((v) => /en[-_]/i.test(v.lang)) || voices[0];
    } catch (e) {
      return null;
    }
  }

  function speak(text) {
    try {
      if (!("speechSynthesis" in window)) return;
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      const v = getVoice();
      if (v) u.voice = v;
      const rate = Number(settings.speechRate) || 1;
      u.rate = Math.min(2, Math.max(0.5, rate));
      u.pitch = 1;
      u.volume = 1;
      window.speechSynthesis.speak(u);
    } catch (e) {}
  }

  function stopSpeaking() {
    try {
      if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    } catch (e) {}
  }

  // ── Floating selection toolbar ──
  function ensureToolbar() {
    if (toolbarEl) return toolbarEl;
    toolbarEl = document.createElement("div");
    toolbarEl.id = "copyclip-toolbar";
    toolbarEl.setAttribute("data-copyclip", "1");
    toolbarEl.style.cssText = [
      "position:absolute",
      "z-index:2147483647",
      "display:flex",
      "gap:4px",
      "padding:6px",
      "background:#0c0c12",
      "border:1px solid #252538",
      "border-radius:10px",
      "box-shadow:0 8px 24px rgba(0,0,0,0.45)",
      "font-family:system-ui,-apple-system,sans-serif",
      "font-size:12px",
      "color:#eeeef8",
      "user-select:none",
      "opacity:0",
      "transition:opacity 120ms ease",
      "pointer-events:auto",
    ].join(";");
    toolbarEl.innerHTML = `
      <button data-act="copy" style="${btnCss()}">📋 Copy</button>
      <button data-act="speak" style="${btnCss()}">🔊 Speak</button>
      <button data-act="save" style="${btnCss('#e2842a','#0c0c12')}">＋ Save</button>
    `;
    toolbarEl.addEventListener("mousedown", (e) => {
      e.stopPropagation();
      e.preventDefault();
    });
    toolbarEl.addEventListener("click", (e) => {
      const btn = e.target.closest("button[data-act]");
      if (!btn) return;
      const sel = window.getSelection();
      const text = sel ? sel.toString().trim() : "";
      if (!text) return;
      const act = btn.dataset.act;
      if (act === "copy") {
        copyToClipboard(text);
        flash(btn, "✓");
      } else if (act === "speak") {
        speak(text);
        flash(btn, "♪");
      } else if (act === "save") {
        try {
          chrome.runtime.sendMessage({ type: "SAVE_CLIP", content: text, source: location.href }, () => {
            if (chrome.runtime.lastError) {}
          });
        } catch (e) {}
        flash(btn, "✓");
      }
    });
    document.documentElement.appendChild(toolbarEl);
    return toolbarEl;
  }

  function btnCss(bg, color) {
    return [
      "all:unset",
      "cursor:pointer",
      "padding:6px 10px",
      "border-radius:6px",
      `background:${bg || "#1c1c2c"}`,
      `color:${color || "#eeeef8"}`,
      "font-weight:600",
      "font-size:12px",
      "line-height:1",
      "transition:transform 80ms ease",
    ].join(";");
  }

  function flash(btn, mark) {
    const orig = btn.textContent;
    btn.textContent = mark;
    setTimeout(() => (btn.textContent = orig), 700);
  }

  function showToolbar(sel, text) {
    try {
      if (!sel || sel.rangeCount === 0) return;
      const range = sel.getRangeAt(0);
      const rect = range.getBoundingClientRect();
      if (!rect || (rect.width === 0 && rect.height === 0)) return;
      const tb = ensureToolbar();
      const top = window.scrollY + rect.top - 44;
      const left = window.scrollX + rect.left + rect.width / 2;
      tb.style.top = Math.max(window.scrollY + 4, top) + "px";
      tb.style.left = left + "px";
      tb.style.transform = "translateX(-50%)";
      requestAnimationFrame(() => (tb.style.opacity = "1"));
      clearTimeout(hideTimer);
      hideTimer = setTimeout(hideToolbar, 6000);
    } catch (e) {}
  }

  function hideToolbar() {
    if (!toolbarEl) return;
    toolbarEl.style.opacity = "0";
    clearTimeout(hideTimer);
  }
})();
