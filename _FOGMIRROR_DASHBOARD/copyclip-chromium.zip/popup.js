// ClawdClip v2.0 popup.js

const CATS = [
  { id: "all",    label: "All",     icon: "◆", color: "#e2842a" },
  { id: "pinned", label: "Pinned",  icon: "★", color: "#eab308" },
  { id: "text",   label: "Text",    icon: "T",  color: "#3b82f6" },
  { id: "link",   label: "Links",   icon: "↗",  color: "#8b5cf6" },
  { id: "code",   label: "Code",    icon: "<>", color: "#22c55e" },
  { id: "cmd",    label: "Cmds",    icon: "$",  color: "#f59e0b" },
  { id: "json",   label: "JSON",    icon: "{}", color: "#06b6d4" },
  { id: "note",   label: "Notes",   icon: "✎",  color: "#ec4899" },
];

let clips = [];
let activeCategory = "all";
let searchQuery = "";
let bulkMode = false;
let selectedIds = new Set();
let editingId = null;
let settings = { theme: "dark", maxClips: 200, notifications: true, deduplication: true, autoCopy: true, readAloud: false, showToolbar: true, voiceURI: "", speechRate: 1 };

// ── Storage helpers ──
function loadClips(cb) {
  if (typeof chrome !== "undefined" && chrome.storage) {
    chrome.storage.local.get(["clips"], r => cb(r.clips || []));
  } else {
    try { cb(JSON.parse(localStorage.getItem("clawdclip_clips") || "[]")); }
    catch(e) { cb([]); }
  }
}

function saveClips() {
  if (typeof chrome !== "undefined" && chrome.storage) {
    chrome.storage.local.set({ clips });
  } else {
    try { localStorage.setItem("clawdclip_clips", JSON.stringify(clips)); }
    catch(e) {}
  }
}

function loadSettings(cb) {
  if (typeof chrome !== "undefined" && chrome.storage) {
    chrome.storage.local.get(["settings"], r => {
      if (r.settings) Object.assign(settings, r.settings);
      cb();
    });
  } else {
    try {
      const s = JSON.parse(localStorage.getItem("clawdclip_settings") || "{}");
      Object.assign(settings, s);
    } catch(e) {}
    cb();
  }
}

function saveSettings() {
  if (typeof chrome !== "undefined" && chrome.storage) {
    chrome.storage.local.set({ settings });
  } else {
    try { localStorage.setItem("clawdclip_settings", JSON.stringify(settings)); }
    catch(e) {}
  }
}

// ── Utilities ──
function detectCategory(text) {
  const t = text.trim();
  if (/^https?:\/\//.test(t) || /^www\./.test(t)) return "link";
  if (/^\{[\s\S]*\}$/.test(t) || /^\[[\s\S]*\]$/.test(t)) return "json";
  if (/^(sudo |curl |npm |pip |docker |git |ssh |cd |ls |cat |grep |node |python|bash |chmod |mkdir )/.test(t)) return "cmd";
  if (/^(import |const |let |var |function |class |def |async |<\w|\/\*|\/\/)/.test(t)) return "code";
  if (/[{}<>()=;]/.test(t) && t.split("\n").length > 2) return "code";
  return "text";
}

function getCat(id) { return CATS.find(c => c.id === id) || CATS[2]; }

function timeAgo(ts) {
  const d = Date.now() - ts;
  const m = Math.floor(d / 60000);
  const h = Math.floor(d / 3600000);
  const dy = Math.floor(d / 86400000);
  if (m < 1) return "now";
  if (m < 60) return m + "m ago";
  if (h < 24) return h + "h ago";
  if (dy < 30) return dy + "d ago";
  return new Date(ts).toLocaleDateString();
}

function esc(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function preview(text, len = 140) {
  const t = text.trim();
  return t.length <= len ? t : t.substring(0, len) + "…";
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function charCount(text) {
  const chars = text.length;
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  const lines = text.split("\n").length;
  if (chars > 1000) return `${(chars/1000).toFixed(1)}k chars`;
  return `${chars}c · ${words}w · ${lines}L`;
}

// ── Theme ──
function applyTheme() {
  document.documentElement.setAttribute("data-theme", settings.theme);
  const btn = document.getElementById("themeBtn");
  btn.textContent = settings.theme === "dark" ? "☀" : "◐";
  btn.title = settings.theme === "dark" ? "Switch to light" : "Switch to dark";
}

// ── Toast ──
let toastTimer;
function showToast(msg, isError = false) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.className = "toast show" + (isError ? " error" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.className = "toast", 2000);
}

// ── Copy ──
function copyText(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    if (btn) {
      btn.textContent = "✓";
      btn.classList.add("copied");
      setTimeout(() => { btn.textContent = "COPY"; btn.classList.remove("copied"); }, 1400);
    }
    showToast("✓ Copied!");
  }).catch(() => {
    const ta = document.createElement("textarea");
    ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.focus(); ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
    showToast("✓ Copied!");
  });
}

// ── Render tabs ──
function renderTabs() {
  const counts = {};
  CATS.forEach(c => counts[c.id] = 0);
  clips.forEach(c => {
    counts[c.cat] = (counts[c.cat] || 0) + 1;
    if (c.pinned) counts["pinned"]++;
  });
  counts["all"] = clips.length;

  document.getElementById("catTabs").innerHTML = CATS.map(cat => `
    <button class="cat-tab ${activeCategory === cat.id ? "active" : ""}" data-cat="${cat.id}">
      <span class="cat-tab-icon" style="color:${cat.color}">${cat.icon}</span>
      ${cat.label}
      <span class="cat-tab-count">${counts[cat.id] || 0}</span>
    </button>
  `).join("");

  document.getElementById("clipCount").textContent = clips.length;
}

// ── Render clips ──
function renderClips() {
  const list = document.getElementById("clipsList");

  let filtered = clips;
  if (activeCategory === "pinned") {
    filtered = clips.filter(c => c.pinned);
  } else if (activeCategory !== "all") {
    filtered = clips.filter(c => c.cat === activeCategory);
  }

  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    filtered = filtered.filter(c =>
      c.content.toLowerCase().includes(q) || c.label.toLowerCase().includes(q)
    );
  }

  // Pinned first
  filtered = [...filtered.filter(c => c.pinned), ...filtered.filter(c => !c.pinned)];

  if (filtered.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="white" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">
            <path d="M16.5 7.5 L8.5 15.5 a3 3 0 0 0 4.243 4.243 L19.5 12.5 a5 5 0 0 0 -7.071 -7.071 L5.5 12.5" />
          </svg>
        </div>
        <div class="empty-title">${searchQuery ? "No results" : "No clips yet"}</div>
        <div class="empty-sub">${searchQuery ? "Try different keywords" : 'Hit "+" to add your first clip'}</div>
      </div>`;
    return;
  }

  list.innerHTML = filtered.map(c => {
    const cat = getCat(c.cat);
    const src = c.source ? (() => { try { return new URL(c.source).hostname; } catch(e) { return ""; } })() : "";
    const isSelected = selectedIds.has(c.id);
    return `
      <div class="clip-card ${isSelected ? "selected" : ""}" data-id="${esc(c.id)}">
        <div class="clip-card-top">
          <button class="clip-select ${isSelected ? "checked" : ""}" data-id="${esc(c.id)}">${isSelected ? "✓" : ""}</button>
          <div class="clip-dot" style="background:${cat.color}"></div>
          <div class="clip-label">${esc(c.label)}</div>
          ${c.editedAt ? '<span class="clip-edited">edited</span>' : ''}
          <button class="clip-pin ${c.pinned ? "pinned" : ""}" data-id="${esc(c.id)}" title="${c.pinned ? "Unpin" : "Pin"}">★</button>
          <button class="clip-edit" data-id="${esc(c.id)}" title="Edit">✎</button>
          <button class="clip-del" data-id="${esc(c.id)}" title="Delete">✕</button>
        </div>
        <div class="clip-preview">${esc(preview(c.content))}</div>
        <div class="clip-footer">
          <div class="clip-meta">
            <span class="clip-time">${timeAgo(c.ts)}</span>
            <span class="clip-chars">${charCount(c.content)}</span>
            ${src ? `<span class="clip-source">${esc(src)}</span>` : ""}
          </div>
          <button class="copy-btn" data-id="${esc(c.id)}">COPY</button>
        </div>
      </div>
    `;
  }).join("");

  if (bulkMode) {
    list.classList.add("bulk-mode");
  } else {
    list.classList.remove("bulk-mode");
  }
}

function render() { renderTabs(); renderClips(); updateBulkCount(); }

// ── Add clip ──
function addClip() {
  const content = document.getElementById("newContent").value.trim();
  if (!content) { showToast("⚠ Nothing to save", true); return; }

  // Dedup check
  if (settings.deduplication) {
    const dupe = clips.find(c => c.content === content);
    if (dupe) {
      dupe.ts = Date.now();
      clips = [dupe, ...clips.filter(c => c.id !== dupe.id)];
      saveClips();
      closeAddForm();
      render();
      showToast("↑ Duplicate moved to top");
      return;
    }
  }

  const labelVal = document.getElementById("newLabel").value.trim();
  const catVal = document.getElementById("newCat").value;
  const cat = catVal === "auto" ? detectCategory(content) : catVal;
  const label = labelVal || content.split("\n")[0].substring(0, 50) || "Untitled";

  const clip = { id: uid(), content, label, cat, pinned: false, source: "", ts: Date.now(), editedAt: null };
  clips.unshift(clip);
  if (clips.length > settings.maxClips) clips = clips.slice(0, settings.maxClips);
  saveClips();
  closeAddForm();
  render();
  showToast("✓ Clip saved!");
}

function closeAddForm() {
  document.getElementById("newContent").value = "";
  document.getElementById("newLabel").value = "";
  document.getElementById("newCat").value = "auto";
  document.getElementById("addForm").classList.remove("open");
  document.getElementById("addBtn").classList.remove("active");
}

// ── Edit clip ──
function startEdit(id) {
  const c = clips.find(x => x.id === id);
  if (!c) return;
  editingId = id;
  document.getElementById("editContent").value = c.content;
  document.getElementById("editLabel").value = c.label;
  document.getElementById("editCat").value = c.cat;
  document.getElementById("editForm").classList.add("open");
  document.getElementById("addForm").classList.remove("open");
  document.getElementById("addBtn").classList.remove("active");
}

function saveEdit() {
  const c = clips.find(x => x.id === editingId);
  if (!c) return;
  c.content = document.getElementById("editContent").value.trim();
  c.label = document.getElementById("editLabel").value.trim() || c.content.split("\n")[0].substring(0, 50);
  c.cat = document.getElementById("editCat").value;
  c.editedAt = Date.now();
  saveClips();
  cancelEdit();
  render();
  showToast("✓ Clip updated!");
}

function cancelEdit() {
  editingId = null;
  document.getElementById("editForm").classList.remove("open");
}

// ── Bulk actions ──
function toggleBulkMode() {
  bulkMode = !bulkMode;
  selectedIds.clear();
  document.getElementById("bulkBar").classList.toggle("open", bulkMode);
  document.getElementById("clipsList").classList.toggle("bulk-mode", bulkMode);
  render();
}

function updateBulkCount() {
  document.getElementById("bulkCount").textContent = selectedIds.size + " selected";
  document.getElementById("selectAllBtn").textContent = selectedIds.size === clips.length ? "☑" : "☐";
}

function bulkCopy() {
  const texts = clips.filter(c => selectedIds.has(c.id)).map(c => c.content);
  if (texts.length) {
    copyText(texts.join("\n\n---\n\n"), null);
    showToast(`✓ Copied ${texts.length} clips`);
  }
}

function bulkPin() {
  clips.forEach(c => { if (selectedIds.has(c.id)) c.pinned = true; });
  saveClips();
  render();
  showToast(`★ Pinned ${selectedIds.size} clips`);
}

function bulkDelete() {
  const count = selectedIds.size;
  clips = clips.filter(c => !selectedIds.has(c.id));
  selectedIds.clear();
  saveClips();
  render();
  showToast(`Deleted ${count} clips`);
}

// ── Export / Import ──
function exportAll() {
  const blob = new Blob([JSON.stringify(clips, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "clawdclip_backup_" + new Date().toISOString().slice(0, 10) + ".json";
  a.click();
  showToast("✓ Exported!");
}

function importData(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    try {
      const data = JSON.parse(ev.target.result);
      if (!Array.isArray(data)) throw new Error();
      const newClips = data.filter(c => c && c.content).map(c => ({
        ...c,
        id: (typeof c.id === "string" && /^[a-z0-9]+$/i.test(c.id)) ? c.id : uid()
      }));
      const existIds = new Set(clips.map(c => c.id));
      const added = newClips.filter(c => !existIds.has(c.id));
      clips = [...added, ...clips].slice(0, settings.maxClips);
      saveClips(); render();
      showToast(`✓ Imported ${added.length} clips!`);
    } catch(err) { showToast("⚠ Invalid file", true); }
  };
  reader.readAsText(file);
  e.target.value = "";
}

// ── Settings ──
function populateVoices() {
  const sel = document.getElementById("settingVoice");
  if (!sel) return;
  let voices = [];
  try { voices = window.speechSynthesis ? window.speechSynthesis.getVoices() : []; } catch(e) {}
  sel.innerHTML = '<option value="">System default</option>' + voices.map(v =>
    `<option value="${esc(v.voiceURI)}">${esc(v.name)} (${esc(v.lang)})</option>`
  ).join("");
  sel.value = settings.voiceURI || "";
}

function openSettings() {
  document.getElementById("settingMaxClips").value = String(settings.maxClips);
  document.getElementById("settingDedup").checked = settings.deduplication;
  document.getElementById("settingNotify").checked = settings.notifications;
  document.getElementById("settingAutoCopy").checked = settings.autoCopy !== false;
  document.getElementById("settingReadAloud").checked = !!settings.readAloud;
  document.getElementById("settingShowToolbar").checked = settings.showToolbar !== false;
  const speed = Number(settings.speechRate) || 1;
  document.getElementById("settingSpeed").value = String(speed);
  document.getElementById("speedLabel").textContent = speed.toFixed(1) + "×";
  populateVoices();
  document.getElementById("settingsPanel").classList.add("open");
  document.getElementById("dropdown").classList.remove("open");
}

function closeSettings() {
  settings.maxClips = parseInt(document.getElementById("settingMaxClips").value);
  settings.deduplication = document.getElementById("settingDedup").checked;
  settings.notifications = document.getElementById("settingNotify").checked;
  settings.autoCopy = document.getElementById("settingAutoCopy").checked;
  settings.readAloud = document.getElementById("settingReadAloud").checked;
  settings.showToolbar = document.getElementById("settingShowToolbar").checked;
  settings.voiceURI = document.getElementById("settingVoice").value || "";
  settings.speechRate = parseFloat(document.getElementById("settingSpeed").value) || 1;
  saveSettings();
  document.getElementById("settingsPanel").classList.remove("open");
  showToast("✓ Settings saved");
}

// Voice list loads asynchronously
try {
  if (window.speechSynthesis) {
    window.speechSynthesis.onvoiceschanged = () => {
      if (document.getElementById("settingsPanel").classList.contains("open")) populateVoices();
    };
  }
} catch(e) {}

document.addEventListener("input", (e) => {
  if (e.target && e.target.id === "settingSpeed") {
    document.getElementById("speedLabel").textContent = parseFloat(e.target.value).toFixed(1) + "×";
  }
});

// ── Event delegation ──
document.getElementById("clipsList").addEventListener("click", e => {
  const selectBtn = e.target.closest(".clip-select");
  if (selectBtn && bulkMode) {
    const id = selectBtn.dataset.id;
    if (selectedIds.has(id)) { selectedIds.delete(id); } else { selectedIds.add(id); }
    render();
    return;
  }

  const copyBtn = e.target.closest(".copy-btn");
  if (copyBtn) {
    const c = clips.find(x => x.id === copyBtn.dataset.id);
    if (c) copyText(c.content, copyBtn);
    return;
  }

  const pinBtn = e.target.closest(".clip-pin");
  if (pinBtn) {
    const c = clips.find(x => x.id === pinBtn.dataset.id);
    if (c) { c.pinned = !c.pinned; saveClips(); render(); }
    return;
  }

  const editBtn = e.target.closest(".clip-edit");
  if (editBtn) {
    startEdit(editBtn.dataset.id);
    return;
  }

  const delBtn = e.target.closest(".clip-del");
  if (delBtn) {
    clips = clips.filter(x => x.id !== delBtn.dataset.id);
    saveClips(); render();
    showToast("Deleted");
    return;
  }

  // Click card = copy (if not bulk)
  if (!bulkMode) {
    const card = e.target.closest(".clip-card");
    if (card) {
      const c = clips.find(x => x.id === card.dataset.id);
      if (c) copyText(c.content, null);
    }
  } else {
    const card = e.target.closest(".clip-card");
    if (card) {
      const id = card.dataset.id;
      if (selectedIds.has(id)) { selectedIds.delete(id); } else { selectedIds.add(id); }
      render();
    }
  }
});

document.getElementById("catTabs").addEventListener("click", e => {
  const tab = e.target.closest(".cat-tab");
  if (tab) { activeCategory = tab.dataset.cat; render(); }
});

// ── Header buttons ──
document.getElementById("addBtn").addEventListener("click", () => {
  cancelEdit();
  const form = document.getElementById("addForm");
  form.classList.toggle("open");
  document.getElementById("addBtn").classList.toggle("active");
  if (form.classList.contains("open")) {
    navigator.clipboard.readText().then(text => {
      if (text && !document.getElementById("newContent").value) {
        document.getElementById("newContent").value = text;
      }
      document.getElementById("newContent").focus();
    }).catch(() => document.getElementById("newContent").focus());
  }
});

document.getElementById("cancelBtn").addEventListener("click", closeAddForm);
document.getElementById("saveBtn").addEventListener("click", addClip);
document.getElementById("editSaveBtn").addEventListener("click", saveEdit);
document.getElementById("editCancelBtn").addEventListener("click", cancelEdit);

document.getElementById("searchBtn").addEventListener("click", () => {
  const bar = document.getElementById("searchBar");
  bar.classList.toggle("open");
  document.getElementById("searchBtn").classList.toggle("active");
  if (bar.classList.contains("open")) document.getElementById("searchInput").focus();
  else { searchQuery = ""; document.getElementById("searchInput").value = ""; render(); }
});

document.getElementById("searchInput").addEventListener("input", e => {
  searchQuery = e.target.value;
  render();
});

document.getElementById("clearSearch").addEventListener("click", () => {
  searchQuery = "";
  document.getElementById("searchInput").value = "";
  render();
  document.getElementById("searchInput").focus();
});

document.getElementById("themeBtn").addEventListener("click", () => {
  settings.theme = settings.theme === "dark" ? "light" : "dark";
  saveSettings();
  applyTheme();
});

// ── Menu ──
document.getElementById("menuBtn").addEventListener("click", e => {
  e.stopPropagation();
  document.getElementById("dropdown").classList.toggle("open");
});

document.addEventListener("click", () => {
  document.getElementById("dropdown").classList.remove("open");
});

document.getElementById("exportBtn").addEventListener("click", () => {
  exportAll();
  document.getElementById("dropdown").classList.remove("open");
});

document.getElementById("importTrigger").addEventListener("click", () => {
  document.getElementById("importFile").click();
  document.getElementById("dropdown").classList.remove("open");
});

document.getElementById("importFile").addEventListener("change", importData);

document.getElementById("clearAllBtn").addEventListener("click", () => {
  if (clips.length === 0) return;
  clips = [];
  saveClips(); render();
  showToast("All clips cleared");
  document.getElementById("dropdown").classList.remove("open");
});

document.getElementById("bulkSelectBtn").addEventListener("click", () => {
  toggleBulkMode();
  document.getElementById("dropdown").classList.remove("open");
});

document.getElementById("settingsBtn").addEventListener("click", openSettings);
document.getElementById("settingsClose").addEventListener("click", closeSettings);

// ── Bulk bar ──
document.getElementById("selectAllBtn").addEventListener("click", () => {
  if (selectedIds.size === clips.length) {
    selectedIds.clear();
  } else {
    clips.forEach(c => selectedIds.add(c.id));
  }
  render();
});

document.getElementById("bulkCopyBtn").addEventListener("click", bulkCopy);
document.getElementById("bulkPinBtn").addEventListener("click", bulkPin);
document.getElementById("bulkDelBtn").addEventListener("click", bulkDelete);
document.getElementById("bulkCloseBtn").addEventListener("click", toggleBulkMode);

// ── Keyboard shortcuts ──
document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    if (bulkMode) toggleBulkMode();
    if (editingId) cancelEdit();
    closeAddForm();
    document.getElementById("searchBar").classList.remove("open");
    document.getElementById("searchBtn").classList.remove("active");
    document.getElementById("dropdown").classList.remove("open");
    document.getElementById("settingsPanel").classList.remove("open");
  }
  if ((e.ctrlKey || e.metaKey) && e.key === "n") {
    e.preventDefault();
    document.getElementById("addBtn").click();
  }
  if ((e.ctrlKey || e.metaKey) && e.key === "f") {
    e.preventDefault();
    document.getElementById("searchBtn").click();
  }
});

// Enter to save in add form
document.getElementById("newContent").addEventListener("keydown", e => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") addClip();
});
document.getElementById("editContent").addEventListener("keydown", e => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter") saveEdit();
});

// ── Init ──
loadSettings(() => {
  applyTheme();
  loadClips(loaded => {
    clips = loaded;
    render();
  });
});
