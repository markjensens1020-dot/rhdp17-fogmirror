// CopyClip Background (Firefox MV2) — uses webextension-polyfill so `chrome.*` works
// Re-uses the same logic as background.js (MV3) by aliasing chrome -> browser.

if (typeof chrome === "undefined" && typeof browser !== "undefined") {
  // eslint-disable-next-line no-global-assign
  self.chrome = browser;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "copyclip-save",
    title: "Save to CopyClip",
    contexts: ["selection"]
  });

  chrome.storage.local.get(["settings"], (r) => {
    if (!r.settings) {
      chrome.storage.local.set({
        settings: { theme: "dark", maxClips: 200, notifications: true, deduplication: true, autoCopy: true, readAloud: false, showToolbar: true, voiceURI: "", speechRate: 1 }
      });
    }
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "copyclip-save" && info.selectionText) {
    saveClip(info.selectionText, (tab && tab.url) || "");
  }
});

function detectCategory(text) {
  const t = text.trim();
  if (/^https?:\/\//.test(t) || /^www\./.test(t)) return "link";
  if (/^\{[\s\S]*\}$/.test(t) || /^\[[\s\S]*\]$/.test(t)) return "json";
  if (/^(sudo |curl |npm |pip |docker |git |ssh |cd |ls |cat |grep |node |python|bash |chmod |mkdir )/.test(t)) return "cmd";
  if (/^(import |const |let |var |function |class |def |async |<\w|\/\*|\/\/)/.test(t)) return "code";
  if (/[{}<>()=;]/.test(t) && t.split("\n").length > 2) return "code";
  return "text";
}

function saveClip(content, sourceUrl) {
  chrome.storage.local.get(["clips", "settings"], (result) => {
    const clips = result.clips || [];
    const settings = result.settings || {};

    if (settings.deduplication !== false) {
      const exists = clips.find((c) => c.content === content);
      if (exists) {
        const filtered = clips.filter((c) => c.id !== exists.id);
        exists.ts = Date.now();
        exists.source = sourceUrl || exists.source;
        filtered.unshift(exists);
        chrome.storage.local.set({ clips: filtered.slice(0, settings.maxClips || 200) });
        return;
      }
    }

    const cat = detectCategory(content);
    const label = content.split("\n")[0].substring(0, 50) || "Untitled";
    const clip = {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2),
      content, label, cat, pinned: false, source: sourceUrl, ts: Date.now(), editedAt: null
    };
    clips.unshift(clip);
    chrome.storage.local.set({ clips: clips.slice(0, settings.maxClips || 200) });
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "SAVE_CLIP") {
    saveClip(msg.content, msg.source || "");
    sendResponse({ ok: true });
  }
  return true;
});
